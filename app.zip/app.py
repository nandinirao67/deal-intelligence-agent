import streamlit as st
from backend import (
    hindsight_service,
    setup_deal_bank,
    store_deal_note,
    recall_deal_memories,
    generate_sales_response
)

# --- Initialize Hindsight background service (only once) ---
if "hindsight_service_started" not in st.session_state:
    hindsight_service.start()
    st.session_state.hindsight_service_started = True

# Page config
st.set_page_config(page_title="Deal Intelligence Agent", page_icon="🧠", layout="wide")

BANK_ID = "sarah_techflow"

# Initialize the bank with fake data on first load
if "initialized" not in st.session_state:
    setup_deal_bank(BANK_ID, "Sarah Jenkins", "TechFlow")
    store_deal_note(BANK_ID, "Sarah is VP of Engineering at TechFlow.", "Discovery")
    store_deal_note(BANK_ID, "Main objection: budget is tight.", "Call 1")
    store_deal_note(BANK_ID, "She is comparing us to Competitor X.", "Call 2")
    store_deal_note(BANK_ID, "Her CTO must approve purchases. Needs a one-pager.", "Call 3")
    st.session_state.initialized = True

# --- SIDEBAR: THE MEMORY VIEWER ---
with st.sidebar:
    st.header("🧠 Hindsight Memory")
    st.caption("What the agent remembers about this deal")

    memories = recall_deal_memories(BANK_ID, "deal information")

    if memories:
        for mem in memories:
            st.markdown(f"- {mem.text}")
    else:
        st.info("No memories stored yet.")

    st.divider()
    st.subheader("➕ Add Deal Note")
    new_note = st.text_area("Paste a call transcript or note:", height=100)
    if st.button("Store in Hindsight"):
        if new_note.strip():
            store_deal_note(BANK_ID, new_note, "Manual entry")
            st.success("✅ Stored! Refresh to see it in memory.")
            st.rerun()

# --- MAIN CHAT INTERFACE ---
st.title("💼 Deal Intelligence Agent")
st.caption("Powered by Hindsight Memory + Groq LLM")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if prompt := st.chat_input("Ask for a follow-up email, deal summary, or strategy..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Recalling deal memories..."):
            result = generate_sales_response(BANK_ID, prompt)
        st.markdown(result["response"])
        st.caption(f"📚 Used {result['memory_count']} memories from Hindsight")

    st.session_state.messages.append({
        "role": "assistant",
        "content": result["response"]
    })
    st.rerun()